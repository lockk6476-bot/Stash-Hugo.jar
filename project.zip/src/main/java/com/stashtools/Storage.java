package com.stashtools;

import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.status.ChunkStatus;

import java.util.ArrayList;
import java.util.List;

public final class Storage {
	private Storage() {}

	public enum Kind {
		CHEST(1f, 0.65f, 0.1f),
		BARREL(0.8f, 0.5f, 0.2f),
		SHULKER(0.8f, 0.3f, 1f),
		ENDER(0.4f, 0.2f, 0.9f),
		HOPPER(0.6f, 0.6f, 0.6f),
		FURNACE(0.9f, 0.3f, 0.3f),
		SPAWNER(0.1f, 1f, 0.3f);

		public final float r, g, b;
		Kind(float r, float g, float b) { this.r = r; this.g = g; this.b = b; }
	}

	/** Identify the block entity by its registry id, so no mapping-specific class names are needed. */
	public static Kind kindOf(BlockEntity be) {
		var key = BuiltInRegistries.BLOCK_ENTITY_TYPE.getKey(be.getType());
		if (key == null) return null;
		return switch (key.getPath()) {
			case "chest", "trapped_chest" -> Kind.CHEST;
			case "barrel" -> Kind.BARREL;
			case "shulker_box" -> Kind.SHULKER;
			case "ender_chest" -> Kind.ENDER;
			case "hopper", "dropper", "dispenser" -> Kind.HOPPER;
			case "furnace", "blast_furnace", "smoker" -> Kind.FURNACE;
			case "mob_spawner", "spawner" -> Kind.SPAWNER;
			default -> null;
		};
	}

	public static boolean espWants(Kind k, Config c) {
		return switch (k) {
			case CHEST -> c.espChests;
			case BARREL -> c.espBarrels;
			case SHULKER -> c.espShulkers;
			case ENDER -> c.espEnder;
			case HOPPER -> c.espHoppers;
			case FURNACE -> c.espFurnaces;
			case SPAWNER -> c.espSpawners;
		};
	}

	/** Loaded client chunks around the player (radius in chunks, capped by render distance). */
	public static List<LevelChunk> loadedChunks(Minecraft mc, int radiusChunks) {
		List<LevelChunk> out = new ArrayList<>();
		if (mc.level == null || mc.player == null) return out;
		int r = Math.min(radiusChunks, mc.options.renderDistance().get());
		int pcx = Mth.floor(mc.player.getX()) >> 4;
		int pcz = Mth.floor(mc.player.getZ()) >> 4;
		for (int dx = -r; dx <= r; dx++) {
			for (int dz = -r; dz <= r; dz++) {
				ChunkAccess c = mc.level.getChunk(pcx + dx, pcz + dz, ChunkStatus.FULL, false);
				if (c instanceof LevelChunk lc) out.add(lc);
			}
		}
		return out;
	}
}
