package com.stashtools;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/** Touch-friendly settings screen: 3 tabs, big buttons, no scrolling needed. */
public class ToolsScreen extends Screen {
	private static int page = 0;
	private int slot = 0;

	public ToolsScreen() {
		super(Component.literal("Stash Tools"));
	}

	@Override
	protected void init() {
		slot = 0;
		Config c = Config.get();

		String[] tabs = {"ESP", "Stash Finder", "Advanced"};
		int tw = 100;
		int x0 = this.width / 2 - (tw * 3 + 8) / 2;
		for (int i = 0; i < tabs.length; i++) {
			final int idx = i;
			Button b = Button.builder(Component.literal(tabs[i]), btn -> {
				page = idx;
				this.rebuildWidgets();
			}).bounds(x0 + i * (tw + 4), 24, tw, 20).build();
			b.active = i != page;
			this.addRenderableWidget(b);
		}

		if (page == 0) {
			toggle("Storage ESP", () -> c.espEnabled, v -> c.espEnabled = v);
			number("Range", () -> c.espRange, v -> c.espRange = v, 16, 16, 256);
			toggle("Chests", () -> c.espChests, v -> c.espChests = v);
			toggle("Barrels", () -> c.espBarrels, v -> c.espBarrels = v);
			toggle("Shulkers", () -> c.espShulkers, v -> c.espShulkers = v);
			toggle("Ender chests", () -> c.espEnder, v -> c.espEnder = v);
			toggle("Hoppers", () -> c.espHoppers, v -> c.espHoppers = v);
			toggle("Furnaces", () -> c.espFurnaces, v -> c.espFurnaces = v);
			toggle("Spawners", () -> c.espSpawners, v -> c.espSpawners = v);
			number("Opacity %", () -> c.espAlphaPct, v -> c.espAlphaPct = v, 5, 10, 80);
		} else if (page == 1) {
			toggle("Stash Finder", () -> c.stashEnabled, v -> c.stashEnabled = v);
			number("Min storage", () -> c.stashMinCount, v -> c.stashMinCount = v, 1, 1, 100);
			number("Min dist", () -> c.stashMinDistance, v -> c.stashMinDistance = v, 250, 0, 100000);
			action("Print found list", () -> printList(Finders.basic));
			action("Clear list", Finders.basic::clear);
		} else {
			toggle("Adv. Finder", () -> c.advEnabled, v -> c.advEnabled = v);
			number("Min score", () -> c.advMinScore, v -> c.advMinScore = v, 1, 1, 300);
			number("Min dist", () -> c.advMinDistance, v -> c.advMinDistance = v, 250, 0, 100000);
			toggle("Spawner alert", () -> c.advSpawnerAlert, v -> c.advSpawnerAlert = v);
			toggle("Disconnect", () -> c.advDisconnect, v -> c.advDisconnect = v);
			toggle("Save to file", () -> c.advSaveFile, v -> c.advSaveFile = v);
			toggle("Discord webhook", () -> c.advWebhook, v -> c.advWebhook = v);
			action("Print found list", () -> printList(Finders.adv));
			action("Clear list", Finders.adv::clear);
		}

		this.addRenderableWidget(Button.builder(Component.literal("Done"), b -> this.onClose())
				.bounds(this.width / 2 - 50, this.height - 26, 100, 20).build());
	}

	private int sx() { return this.width / 2 - 155 + (slot % 2) * 160; }
	private int sy() { return 52 + (slot / 2) * 23; }

	private static Component label(String name, boolean on) {
		return Component.literal(name + ": " + (on ? "ON" : "OFF"));
	}

	private void toggle(String name, BooleanSupplier get, Consumer<Boolean> set) {
		int x = sx(), y = sy();
		slot++;
		this.addRenderableWidget(Button.builder(label(name, get.getAsBoolean()), btn -> {
			set.accept(!get.getAsBoolean());
			btn.setMessage(label(name, get.getAsBoolean()));
		}).bounds(x, y, 150, 20).build());
	}

	private void number(String name, IntSupplier get, IntConsumer set, int step, int min, int max) {
		int x = sx(), y = sy();
		slot++;
		Button mid = Button.builder(Component.literal(name + ": " + get.getAsInt()), b -> { })
				.bounds(x + 22, y, 106, 20).build();
		Button minus = Button.builder(Component.literal("-"), b -> {
			set.accept(Math.max(min, get.getAsInt() - step));
			mid.setMessage(Component.literal(name + ": " + get.getAsInt()));
		}).bounds(x, y, 20, 20).build();
		Button plus = Button.builder(Component.literal("+"), b -> {
			set.accept(Math.min(max, get.getAsInt() + step));
			mid.setMessage(Component.literal(name + ": " + get.getAsInt()));
		}).bounds(x + 130, y, 20, 20).build();
		this.addRenderableWidget(minus);
		this.addRenderableWidget(mid);
		this.addRenderableWidget(plus);
	}

	private void action(String name, Runnable r) {
		int x = sx(), y = sy();
		slot++;
		this.addRenderableWidget(Button.builder(Component.literal(name), b -> r.run())
				.bounds(x, y, 150, 20).build());
	}

	private void printList(java.util.Map<Long, Finders.Hit> map) {
		var mc = this.minecraft;
		if (map.isEmpty()) {
			Finders.say(mc, "\u00a77[StashTools] list is empty");
			return;
		}
		int n = 0;
		for (Finders.Hit h : map.values()) {
			Finders.say(mc, "\u00a77- x=" + h.x() + " z=" + h.z() + " storage=" + h.storage()
					+ " shulker=" + h.shulkers() + " spawner=" + h.spawners());
			if (++n >= 15) break;
		}
	}

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
		super.render(g, mouseX, mouseY, delta);
		g.drawCenteredString(this.font, this.title, this.width / 2, 8, 0xFFFFFFFF);
	}

	@Override
	public void removed() {
		Config.save();
	}
}
