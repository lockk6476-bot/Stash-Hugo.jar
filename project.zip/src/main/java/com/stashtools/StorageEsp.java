package com.stashtools;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MappableRingBuffer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.OptionalDouble;
import java.util.OptionalInt;

/**
 * Storage ESP: draws translucent boxes through walls around chests, barrels, shulkers...
 * Rendering follows the Fabric docs "Rendering in the World" for 1.21.11.
 */
public class StorageEsp {
	private static final RenderPipeline PIPELINE = RenderPipelines.register(
			RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
					.withLocation(Identifier.fromNamespaceAndPath("stashtools", "pipeline/esp_through_walls"))
					.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
					.build());

	private static final ByteBufferBuilder ALLOCATOR = new ByteBufferBuilder(RenderType.SMALL_BUFFER_SIZE);
	private static final Vector4f COLOR_MODULATOR = new Vector4f(1f, 1f, 1f, 1f);
	private static final Vector3f MODEL_OFFSET = new Vector3f();
	private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();

	private MappableRingBuffer vertexBuffer;
	/** x, y, z, r, g, b */
	private final List<float[]> boxes = new ArrayList<>();

	public void register() {
		WorldRenderEvents.BEFORE_TRANSLUCENT.register(this::onRender);
	}

	/** Called every few ticks: collect storage block entities near the player. */
	public void refresh(Minecraft mc) {
		boxes.clear();
		Config c = Config.get();
		if (!c.espEnabled || mc.level == null || mc.player == null) return;

		double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
		double r2 = (double) c.espRange * c.espRange;

		for (LevelChunk chunk : Storage.loadedChunks(mc, c.espRange / 16 + 1)) {
			for (BlockEntity be : chunk.getBlockEntities().values()) {
				Storage.Kind k = Storage.kindOf(be);
				if (k == null || !Storage.espWants(k, c)) continue;
				BlockPos p = be.getBlockPos();
				double dx = p.getX() + 0.5 - px, dy = p.getY() + 0.5 - py, dz = p.getZ() + 0.5 - pz;
				if (dx * dx + dy * dy + dz * dz > r2) continue;
				boxes.add(new float[]{p.getX(), p.getY(), p.getZ(), k.r, k.g, k.b});
				if (boxes.size() >= 2000) return;
			}
		}
	}

	private void onRender(WorldRenderContext context) {
		Config c = Config.get();
		if (!c.espEnabled || boxes.isEmpty()) return;

		PoseStack matrices = context.matrices();
		Vec3 cam = context.worldState().cameraRenderState.pos;

		matrices.pushPose();
		matrices.translate(-cam.x, -cam.y, -cam.z);

		BufferBuilder buffer = new BufferBuilder(ALLOCATOR, PIPELINE.getVertexFormatMode(), PIPELINE.getVertexFormat());
		float a = c.espAlphaPct / 100f;
		for (float[] b : boxes) {
			float e = 0.002f;
			addBox(matrices.last().pose(), buffer,
					b[0] - e, b[1] - e, b[2] - e, b[0] + 1 + e, b[1] + 1 + e, b[2] + 1 + e,
					b[3], b[4], b[5], a);
		}
		matrices.popPose();

		draw(Minecraft.getInstance(), buffer);
	}

	private static void addBox(Matrix4fc m, BufferBuilder buf, float x0, float y0, float z0, float x1, float y1, float z1,
							   float r, float g, float b, float a) {
		// front
		buf.addVertex(m, x0, y0, z1).setColor(r, g, b, a);
		buf.addVertex(m, x1, y0, z1).setColor(r, g, b, a);
		buf.addVertex(m, x1, y1, z1).setColor(r, g, b, a);
		buf.addVertex(m, x0, y1, z1).setColor(r, g, b, a);
		// back
		buf.addVertex(m, x1, y0, z0).setColor(r, g, b, a);
		buf.addVertex(m, x0, y0, z0).setColor(r, g, b, a);
		buf.addVertex(m, x0, y1, z0).setColor(r, g, b, a);
		buf.addVertex(m, x1, y1, z0).setColor(r, g, b, a);
		// left
		buf.addVertex(m, x0, y0, z0).setColor(r, g, b, a);
		buf.addVertex(m, x0, y0, z1).setColor(r, g, b, a);
		buf.addVertex(m, x0, y1, z1).setColor(r, g, b, a);
		buf.addVertex(m, x0, y1, z0).setColor(r, g, b, a);
		// right
		buf.addVertex(m, x1, y0, z1).setColor(r, g, b, a);
		buf.addVertex(m, x1, y0, z0).setColor(r, g, b, a);
		buf.addVertex(m, x1, y1, z0).setColor(r, g, b, a);
		buf.addVertex(m, x1, y1, z1).setColor(r, g, b, a);
		// top
		buf.addVertex(m, x0, y1, z1).setColor(r, g, b, a);
		buf.addVertex(m, x1, y1, z1).setColor(r, g, b, a);
		buf.addVertex(m, x1, y1, z0).setColor(r, g, b, a);
		buf.addVertex(m, x0, y1, z0).setColor(r, g, b, a);
		// bottom
		buf.addVertex(m, x0, y0, z0).setColor(r, g, b, a);
		buf.addVertex(m, x1, y0, z0).setColor(r, g, b, a);
		buf.addVertex(m, x1, y0, z1).setColor(r, g, b, a);
		buf.addVertex(m, x0, y0, z1).setColor(r, g, b, a);
	}

	private void draw(Minecraft client, BufferBuilder buffer) {
		MeshData built = buffer.buildOrThrow();
		MeshData.DrawState dp = built.drawState();
		VertexFormat format = dp.format();

		GpuBuffer vertices = upload(dp, format, built);

		GpuBuffer indices;
		VertexFormat.IndexType indexType;
		if (PIPELINE.getVertexFormatMode() == VertexFormat.Mode.QUADS) {
			built.sortQuads(ALLOCATOR, RenderSystem.getProjectionType().vertexSorting());
			indices = PIPELINE.getVertexFormat().uploadImmediateIndexBuffer(built.indexBuffer());
			indexType = built.drawState().indexType();
		} else {
			RenderSystem.AutoStorageIndexBuffer shape = RenderSystem.getSequentialBuffer(PIPELINE.getVertexFormatMode());
			indices = shape.getBuffer(dp.indexCount());
			indexType = shape.type();
		}

		GpuBufferSlice dynamicTransforms = RenderSystem.getDynamicUniforms()
				.writeTransform(RenderSystem.getModelViewMatrix(), COLOR_MODULATOR, MODEL_OFFSET, TEXTURE_MATRIX);

		try (RenderPass pass = RenderSystem.getDevice().createCommandEncoder().createRenderPass(
				() -> "stashtools esp", client.getMainRenderTarget().getColorTextureView(), OptionalInt.empty(),
				client.getMainRenderTarget().getDepthTextureView(), OptionalDouble.empty())) {
			pass.setPipeline(PIPELINE);
			RenderSystem.bindDefaultUniforms(pass);
			pass.setUniform("DynamicTransforms", dynamicTransforms);
			pass.setVertexBuffer(0, vertices);
			pass.setIndexBuffer(indices, indexType);
			pass.drawIndexed(0, 0, dp.indexCount(), 1);
		}

		built.close();
		vertexBuffer.rotate();
	}

	private GpuBuffer upload(MeshData.DrawState dp, VertexFormat format, MeshData built) {
		int size = dp.vertexCount() * format.getVertexSize();
		if (vertexBuffer == null || vertexBuffer.size() < size) {
			if (vertexBuffer != null) vertexBuffer.close();
			vertexBuffer = new MappableRingBuffer(() -> "stashtools esp",
					GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_MAP_WRITE, size);
		}
		CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
		try (GpuBuffer.MappedView view = encoder.mapBuffer(
				vertexBuffer.currentBuffer().slice(0, built.vertexBuffer().remaining()), false, true)) {
			MemoryUtil.memCopy(built.vertexBuffer(), view.data());
		}
		return vertexBuffer.currentBuffer();
	}

	public void close() {
		ALLOCATOR.close();
		if (vertexBuffer != null) {
			vertexBuffer.close();
			vertexBuffer = null;
		}
	}
}
