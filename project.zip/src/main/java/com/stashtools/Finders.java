package com.stashtools;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

/** Stash Finder (basic) and Advanced Stash Finder. */
public final class Finders {
	private Finders() {}

	public record Hit(int cx, int cz, int storage, int shulkers, int spawners, int score) {
		public int x() { return cx * 16 + 8; }
		public int z() { return cz * 16 + 8; }
	}

	public static final Map<Long, Hit> basic = new LinkedHashMap<>();
	public static final Map<Long, Hit> adv = new LinkedHashMap<>();
	private static Object lastLevel;
	private static final HttpClient HTTP = HttpClient.newHttpClient();

	public static void clear() {
		basic.clear();
		adv.clear();
	}

	public static void tick(Minecraft mc) {
		if (mc.level == null || mc.player == null) return;
		if (mc.level != lastLevel) { // new world / dimension
			lastLevel = mc.level;
			clear();
		}
		Config c = Config.get();
		if (!c.stashEnabled && !c.advEnabled) return;

		for (LevelChunk chunk : Storage.loadedChunks(mc, 32)) {
			int cx = chunk.getPos().x;
			int cz = chunk.getPos().z;
			long key = ((long) cx << 32) | (cz & 0xFFFFFFFFL);

			boolean needBasic = c.stashEnabled && !basic.containsKey(key);
			boolean needAdv = c.advEnabled && !adv.containsKey(key);
			if (!needBasic && !needAdv) continue;

			int storage = 0, shulkers = 0, spawners = 0;
			for (BlockEntity be : chunk.getBlockEntities().values()) {
				Storage.Kind k = Storage.kindOf(be);
				if (k == null) continue;
				switch (k) {
					case CHEST, BARREL -> storage++;
					case SHULKER -> { storage++; shulkers++; }
					case SPAWNER -> spawners++;
					default -> { }
				}
			}
			if (storage == 0 && spawners == 0) continue;

			double dist = Math.hypot(cx * 16 + 8, cz * 16 + 8); // distance from 0,0 (spawn on most servers)

			if (needBasic && storage >= c.stashMinCount && dist >= c.stashMinDistance) {
				Hit h = new Hit(cx, cz, storage, shulkers, spawners, storage);
				basic.put(key, h);
				say(mc, "\u00a76[StashFinder] \u00a7fchunk " + cx + "," + cz + "  x=" + h.x() + " z=" + h.z()
						+ "  storage=" + storage);
			}

			if (needAdv) {
				int score = storage + shulkers * 2 + (c.advSpawnerAlert ? spawners * 5 : 0);
				if (score >= c.advMinScore && dist >= c.advMinDistance) {
					Hit h = new Hit(cx, cz, storage, shulkers, spawners, score);
					adv.put(key, h);
					onAdvancedHit(mc, c, h);
				}
			}
		}
	}

	private static void onAdvancedHit(Minecraft mc, Config c, Hit h) {
		String text = "chunk " + h.cx() + "," + h.cz() + " | x=" + h.x() + " z=" + h.z()
				+ " | storage=" + h.storage() + " shulker=" + h.shulkers()
				+ " spawner=" + h.spawners() + " score=" + h.score();
		String tag = (c.advSpawnerAlert && h.spawners() > 0) ? " \u00a7c[SPAWNER]" : "";
		say(mc, "\u00a7b[AdvStash] \u00a7f" + text + tag);

		String server = mc.getCurrentServer() != null ? mc.getCurrentServer().ip : "singleplayer";

		if (c.advSaveFile) {
			try {
				var file = FabricLoader.getInstance().getConfigDir().resolve("stashtools-found.txt");
				String line = LocalDateTime.now() + " | " + server + " | " + text + System.lineSeparator();
				Files.writeString(file, line, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
			} catch (Exception ignored) { }
		}

		if (c.advWebhook && c.advWebhookUrl != null && c.advWebhookUrl.startsWith("https://")) {
			try {
				String json = "{\"content\":\"" + esc("Stash found on " + server + ": " + text) + "\"}";
				HttpRequest req = HttpRequest.newBuilder(URI.create(c.advWebhookUrl))
						.header("Content-Type", "application/json")
						.POST(HttpRequest.BodyPublishers.ofString(json))
						.build();
				HTTP.sendAsync(req, HttpResponse.BodyHandlers.discarding());
			} catch (Exception ignored) { }
		}

		if (c.advDisconnect && mc.getConnection() != null) {
			c.advEnabled = false; // avoid a reconnect loop
			Config.save();
			mc.getConnection().getConnection().disconnect(Component.literal("StashTools: stash found at " + h.x() + ", " + h.z()));
		}
	}

	private static String esc(String s) {
		return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
	}

	public static void say(Minecraft mc, String msg) {
		if (mc.player != null) mc.player.displayClientMessage(Component.literal(msg), false);
	}
}
