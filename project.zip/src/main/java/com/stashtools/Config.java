package com.stashtools;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class Config {
	// Storage ESP
	public boolean espEnabled = false;
	public int espRange = 128;
	public int espAlphaPct = 35;
	public boolean espChests = true, espBarrels = true, espShulkers = true, espEnder = true;
	public boolean espHoppers = false, espFurnaces = false, espSpawners = true;

	// Stash Finder (basic)
	public boolean stashEnabled = false;
	public int stashMinCount = 5;
	public int stashMinDistance = 1000;

	// Advanced Stash Finder
	public boolean advEnabled = false;
	public int advMinScore = 10;
	public int advMinDistance = 1000;
	public boolean advSpawnerAlert = true;
	public boolean advDisconnect = false;
	public boolean advSaveFile = true;
	public boolean advWebhook = false;
	public String advWebhookUrl = "";

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static Config instance = new Config();

	public static Config get() { return instance; }

	private static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("stashtools.json");
	}

	public static void load() {
		try {
			Path p = path();
			if (Files.exists(p)) {
				Config c = GSON.fromJson(Files.readString(p), Config.class);
				if (c != null) instance = c;
			}
		} catch (Exception e) {
			System.err.println("[StashTools] config load failed: " + e);
		}
	}

	public static void save() {
		try {
			Files.writeString(path(), GSON.toJson(instance));
		} catch (Exception e) {
			System.err.println("[StashTools] config save failed: " + e);
		}
	}
}
